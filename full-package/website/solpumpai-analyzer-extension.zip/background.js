// background.js - Service worker for notifications and storage
console.log('[Solpump Analyzer] Background service worker loaded');

// Handle messages from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'showNotification') {
    showNotification(message.alert, message.analysis);
  } else if (message.action === 'statsUpdate') {
    // Could broadcast to other tabs or store globally
    updateBadge(message.stats);
  }
});

function showNotification(alert, analysis) {
  const options = {
    type: 'basic',
    iconUrl: 'icon128.png',
    title: alert.title,
    message: alert.message,
    priority: alert.priority || 1,
    requireInteraction: alert.priority === 2
  };

  chrome.notifications.create('solpump-alert-' + Date.now(), options, (notificationId) => {
    console.log('[Solpump Analyzer] Notification shown:', notificationId);
    
    // Auto-clear after 10 seconds unless high priority
    if (alert.priority < 2) {
      setTimeout(() => {
        chrome.notifications.clear(notificationId);
      }, 10000);
    }
  });
}

function updateBadge(stats) {
  if (!stats || !stats.prediction) return;

  const prediction = stats.prediction;
  
  // Update badge based on confidence
  let badgeText = '';
  let badgeColor = '#666666';

  if (prediction.confidence === 'HIGH') {
    badgeText = '🔥';
    badgeColor = '#FF0000';
  } else if (prediction.confidence === 'MEDIUM') {
    badgeText = '⚡';
    badgeColor = '#FFA500';
  } else if (prediction.recommendation === 'BET') {
    badgeText = '💡';
    badgeColor = '#00AA00';
  }

  chrome.action.setBadgeText({ text: badgeText });
  chrome.action.setBadgeBackgroundColor({ color: badgeColor });
}

// Handle notification clicks
chrome.notifications.onClicked.addListener((notificationId) => {
  console.log('[Solpump Analyzer] Notification clicked:', notificationId);
  
  // Open the Solpump site
  chrome.tabs.create({ url: 'https://solpump.io' });
  
  // Clear the notification
  chrome.notifications.clear(notificationId);
});

// Periodic cleanup of old data
chrome.alarms.create('cleanup', { periodInMinutes: 60 });

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'cleanup') {
    chrome.storage.local.get(['allResults'], (data) => {
      if (data.allResults && data.allResults.length > 10000) {
        // Keep only last 10000
        const trimmed = data.allResults.slice(-10000);
        chrome.storage.local.set({ allResults: trimmed });
        console.log('[Solpump Analyzer] Cleaned up old data');
      }
    });
  }
});
