// injected.js - Runs in page context to intercept WebSocket
(function() {
  console.log('[Solpump Analyzer] Injected script loaded');

  // Intercept WebSocket
  const OriginalWebSocket = window.WebSocket;
  
  window.WebSocket = function(...args) {
    const ws = new OriginalWebSocket(...args);
    
    console.log('[Solpump Analyzer] WebSocket connection:', args[0]);
    
    // Intercept messages
    const originalAddEventListener = ws.addEventListener;
    ws.addEventListener = function(type, listener, ...rest) {
      if (type === 'message') {
        const wrappedListener = function(event) {
          try {
            const data = JSON.parse(event.data);
            
            // Look for crash results in various possible formats
            if (data.type === 'crash' || data.event === 'crash_result' || data.result) {
              const multiplier = data.crashPoint || data.multiplier || data.result || data.crash;
              if (multiplier) {
                window.postMessage({
                  type: 'CRASH_RESULT',
                  multiplier: parseFloat(multiplier),
                  data: data
                }, '*');
              }
            }
            
            // Game state updates
            if (data.type === 'game_state' || data.state) {
              window.postMessage({
                type: 'GAME_STATE',
                state: data.state || data,
                data: data
              }, '*');
            }
          } catch (e) {
            // Not JSON or parsing failed
          }
          
          return listener.apply(this, arguments);
        };
        return originalAddEventListener.call(this, type, wrappedListener, ...rest);
      }
      return originalAddEventListener.call(this, type, listener, ...rest);
    };
    
    return ws;
  };

  // Also intercept fetch for REST API calls
  const originalFetch = window.fetch;
  window.fetch = function(...args) {
    return originalFetch.apply(this, args).then(response => {
      const clonedResponse = response.clone();
      
      // Check if this looks like a game-related endpoint
      const url = typeof args[0] === 'string' ? args[0] : args[0].url;
      
      if (url.includes('crash') || url.includes('game') || url.includes('history')) {
        clonedResponse.json().then(data => {
          // Look for crash results
          if (data.history || data.results || data.games) {
            const results = data.history || data.results || data.games;
            if (Array.isArray(results)) {
              results.forEach(result => {
                const multiplier = result.crashPoint || result.multiplier || result.crash;
                if (multiplier) {
                  window.postMessage({
                    type: 'CRASH_RESULT',
                    multiplier: parseFloat(multiplier),
                    source: 'api'
                  }, '*');
                }
              });
            }
          }
        }).catch(() => {});
      }
      
      return response;
    });
  };

  console.log('[Solpump Analyzer] Interception active');
})();
